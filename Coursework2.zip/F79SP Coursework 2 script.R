D = 2

#Create a function to simulate all necessary quantities.
simulation.fn <- function(nsims, operator) {
  
  #Selecting parameters depending on operator.
  if (operator == "FoodBear") {
    lambda = 120
    n.driver = 80
    income = D + 15
    driver.pay = 10
  } else if (operator == "SnatchFood")
  {
    lambda = 110
    n.driver = 60
    income = D + 15
    driver.pay = 13 + D / 10
  }
  
  #Create empty vectors to store values of number of success and total orders per simulation
  order.success.total.ps = vector()
  number.total.ps = vector()
  
  #Starts at 8 a.m.
  t = 8
  
  #Repeat for nsims number of simulations
  for (n in 1:nsims) {
    driver.time = rep(0, n.driver)
    order.success.pi = 0
    order.success.total = 0
    number.total = 0
    
    #Simulate Poisson process from 8a.m. to 10 p.m. (2200 hours)
    for (l in 0:13) {
      t = 8 + l
      
      #Peak period
      if (any(t == c(8, 12, 13, 18, 19))) {
        #Generate number of points in the interval
        number = rpois(1, lambda * 1)
        
        #Generate arrival times and sorting it to form a Poisson process.
        order.time = runif(number, t, t + 1)
        order.time = sort(order.time)
        
        #Give drivers new orders if they've finished the previous one after 1 hour
        for (i in 1:length(order.time)) {
          driver.time[(driver.time + 1) < order.time[i]][1] = order.time[i]
          driver.time <- sort(driver.time)
        }
        #Count the number of drivers that took a new order.
        order.success.pi = length(na.omit(match(driver.time, order.time)))
        
      } else if (any(t == c(9:11, 14, 17, 20, 21))) {
        #Repeat for 0.75 of the rate of  the peak period
        number <- rpois(1, 0.75 * lambda * 1)
        
        order.time <- runif(number, t, t + 1)
        order.time <- sort(order.time)
        
        for (i in 1:length(order.time)) {
          driver.time[(driver.time + 1) < order.time[i]][1] = order.time[i]
          driver.time <- sort(driver.time)
        }
        order.success.pi = length(na.omit(match(driver.time, order.time)))
        
      } else if (any(t == c(15, 16))) {
        #Repeat for 0.5 of the rate of  the peak period
        number <- rpois(1, 0.5 * lambda * 1)
        
        order.time <- runif(number, t, t + 1)
        order.time <- sort(order.time)
        
        
        for (i in 1:length(order.time)) {
          driver.time[(driver.time + 1) < order.time[i]][1] = order.time[i]
          driver.time <- sort(driver.time)
        }
        order.success.pi = length(na.omit(match(driver.time, order.time)))
        
      } else{
        #Stop the Poisson process when it is 10 p.m. (2200 hours) 
        next
      }
      #Count the total number of orders received and successes
      order.success.total = order.success.total + order.success.pi
      number.total = number.total + number
    }
    #Store the values of the total number of orders received and success in a vector
    order.success.total.ps[n] = order.success.total
    number.total.ps[n] = number.total
  }
  #Calculate the averages of the quantities.
  average.order.success = sum(order.success.total.ps) / nsims
  average.order.fail = sum(number.total.ps - order.success.total.ps) / nsims
  expected.profit = (sum(order.success.total.ps * income) / nsims) - (14 * driver.pay * n.driver)
  return(c(average.order.success, average.order.fail, expected.profit))
}

#Create empty vectors to store the simulation data
FB.data <- vector()
SF.data <- vector()

#Simulate 5000 simulations for FoodBear
FB.data <- simulation.fn(5000, operator = "FoodBear")
Quantity1 <- FB.data[1]
Quantity2 <- FB.data[2]
Quantity3 <- FB.data[3]

#Simulate 5000 simulations for SnatchFood
SF.data <- simulation.fn(5000, operator = "SnatchFood")
Quantity4 <- SF.data[1]
Quantity5 <- SF.data[2]
Quantity6 <- SF.data[3]
