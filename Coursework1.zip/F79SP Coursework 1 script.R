#Setting the parameters of the probabilities
D <- 2
k <- D/5 
i <- 0:49
cus <- 10000

#Create a function to simulate the necessary quantities
simulation.fn <- function (trials, airline, n = NULL) {
  ##Input:     trials - number of customers
  ##           airline - either BryanAir or OxygenAsia
  ##           n - number of years (optional)
  ##
  ##Output:    Item 1 in list: Long-term expected number of passengers with different air miles
  ##           Item 2 in list: Average profit per year in the long-term
  ##(optional) Item 3 in list: Expected number of passengers with different air miles after n years
  
  #Create empty matrices for the transition matrix and the profit matrix
  trans.matrix <- matrix(0, nrow = length(i), ncol = length(i))
  profit.matrix <- matrix(0, nrow = length(i), ncol = length(i))
  
  #Create a vector for the initial distribution
  initial.dist <- as.vector(c(1, rep(0,49)))
  
  #Fill in the values for the transition matrix
  for (a in 1:length(i)) {
    for (b in 1:length(i)) {
      if (a > b) {
        #100m miles travelled
        m <- a - b
        
        #Fill probabilities for different airlines
        if (airline == "BryanAir") {
          trans.matrix[a,b] <- 0.3*exp(-m) 
        } else {
          trans.matrix[a,b] <- 0.5*exp(-m)
        }
        
      } else if (a < b) {
        #100m miles travelled
        m <- b - a
        
        #Fill probabilities for different airlines
        if (airline == "BryanAir") {
          trans.matrix[a,b] <- 0.03*(1-exp(-i[a]-1))*(5+k)*exp(-m)
        } else {
          trans.matrix[a,b] <- 0.05*(1-exp(-i[a]-1))*(5+k)*exp(-m)
        }
      }
    }
    #Fill the remaining probabilities where a = b, customer doesn't fly
    trans.matrix[a,a] <- 1 - rowSums(trans.matrix)[a]
  }
  #Find the limiting distribution by raising the transition matrix to a very large exponent
  limit.dist <- trans.matrix
  for (p in 1:10000) {
    limit.dist <- limit.dist %*% trans.matrix
  }
  #Output 1: Expected number of passengers with different amounts of air miles in the long-term 
  quantity <- trials * initial.dist %*% limit.dist
  
  #Fill in the rates per mile into the profit matrix
  for (a in 1:length(i)) {
    for (b in 1:length(i)) {
      if (b + a <= 50) {
        #Rates per mile depending on which airline
        if (airline == "BryanAir") {
          profit.matrix[a, b+a] <- 2 * 100 * b 
          profit.matrix[b+a, a] <- 1.5 * 100 * b
        } else {
          profit.matrix[a, b+a] <- 1 * 100 * b 
          profit.matrix[b+a, a] <- 0.8 * 100 * b
        }
      }
    } 
  }
  #Yearly membership fee depending on which airline
  if (airline == "BryanAir") {
    yearly.fee <- 8
  } else {
    yearly.fee <- 15
  }
  #Output 2: Average profit per year in the long-term
  profit <- sum(quantity %*% (profit.matrix * trans.matrix)) + trials*yearly.fee
  
  #If argument n is present then calculate the expected number of passengers after n years
  if (is.double(n) == T) {
    #Raise the transition matrix to the power of n
    n.trans.matrix <- trans.matrix
    for (p in 1:(n-1)) {
      n.trans.matrix <- n.trans.matrix %*% trans.matrix
    }
    #Use P^n to obtain output 3
    n.cus <- trials * initial.dist %*% n.trans.matrix
  }
  #Return the output which depends on whether n is present
  if (is.double(n) == T) {
    return(n.cus)
  } else {
    return(list(quantity, profit))
  }
}

#Run the simulations for the different quantities
Quantity1 <- simulation.fn(cus, airline ="BryanAir")[1]
Quantity2 <- simulation.fn(cus, airline = "OxygenAsia")[1]
Quantity3 <- unlist(simulation.fn(cus, airline = "BryanAir")[2])
Quantity4 <- unlist(simulation.fn(cus, airline = "OxygenAsia")[2])
Quantity5 <- unlist(simulation.fn(cus, airline = "BryanAir", n = 10))[1]
Quantity6 <- unlist(simulation.fn(cus, airline = "OxygenAsia", n = 10))[1]

